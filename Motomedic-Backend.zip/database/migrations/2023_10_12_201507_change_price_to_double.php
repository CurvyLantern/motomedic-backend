<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangePriceToDouble extends Migration
{
  public function up()
  {
    Schema::table('products', function (Blueprint $table) {
      // Change 'price' column to a double with 8 total digits and 2 decimal places
      $table->double('price', 10, 2)->change();
    });
  }

  public function down()
  {
    Schema::table('products', function (Blueprint $table) {
      // Revert the 'price' column to its previous data type (e.g., decimal)
      $table->decimal('price', 10, 2)->change();
    });
  }
}
