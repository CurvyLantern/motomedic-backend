<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Sanctum\Http\Controllers\CsrfCookieController;

class CsrfController extends CsrfCookieController
{
    //
}
